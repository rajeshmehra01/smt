package com.example.converter;

import io.confluent.connect.avro.AvroConverter;
import io.confluent.connect.avro.AvroData;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.errors.DataException;
import org.apache.kafka.connect.sink.SinkRecord;

import java.math.BigInteger;
import java.util.Map;

public class CustomAvroConverter extends AvroConverter {

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        super.configure(configs, isKey);
    }

    @Override
    public Object toConnectData(String topic, byte[] value) {
        try {
            return super.toConnectData(topic, value);
        } catch (DataException e) {
            if (e.getCause() instanceof NumberFormatException &&
                e.getCause().getMessage().contains("Zero length BigInteger")) {
                // Fallback for zero-length BigInteger error
                Schema schema = AvroData.ANYTHING_SCHEMA;
                Struct fallbackStruct = new Struct(schema);
                return new org.apache.kafka.connect.data.SchemaAndValue(schema, fallbackStruct);
            } else {
                throw e;
            }
        }
    }
}
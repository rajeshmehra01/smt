package com.example.kafka.connect.transforms;

import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.data.Field;
import org.apache.kafka.connect.transforms.Transformation;
import org.apache.kafka.connect.transforms.util.SimpleConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.Map;

public class SanitizeDecimalFields<R extends ConnectRecord<R>> implements Transformation<R> {

    public static final String OVERVIEW_DOC = "Sanitizes decimal fields by replacing empty byte arrays with default BigDecimal or null.";
    public static final String REPLACE_WITH_ZERO_CONFIG = "replace.with.zero";
    private boolean replaceWithZero;

    @Override
    public void configure(Map<String, ?> configs) {
        SimpleConfig config = new SimpleConfig(CONFIG_DEF, configs);
        replaceWithZero = config.getBoolean(REPLACE_WITH_ZERO_CONFIG);
    }

    @Override
    public R apply(R record) {
        if (record.value() == null || !(record.value() instanceof Struct)) {
            return record;
        }

        Struct valueStruct = (Struct) record.value();
        Schema schema = valueStruct.schema();
        Struct updatedStruct = new Struct(schema);

        for (Field field : schema.fields()) {
            Object value = valueStruct.get(field);
            Schema fieldSchema = field.schema();

            if (fieldSchema.name() != null && fieldSchema.name().equals("org.apache.kafka.connect.data.Decimal")) {
                if (value == null) {
                    updatedStruct.put(field.name(), replaceWithZero ? BigDecimal.ZERO : null);
                } else if (value instanceof ByteBuffer && ((ByteBuffer) value).remaining() == 0) {
                    updatedStruct.put(field.name(), replaceWithZero ? BigDecimal.ZERO : null);
                } else {
                    updatedStruct.put(field.name(), value);
                }
            } else {
                updatedStruct.put(field.name(), value);
            }
        }

        return record.newRecord(record.topic(), record.kafkaPartition(), record.keySchema(), record.key(), schema, updatedStruct, record.timestamp());
    }

    @Override
    public void close() {}

    @Override
    public ConfigDef config() {
        return CONFIG_DEF;
    }

    private static final ConfigDef CONFIG_DEF = new ConfigDef()
        .define(REPLACE_WITH_ZERO_CONFIG, ConfigDef.Type.BOOLEAN, true, ConfigDef.Importance.MEDIUM, "Replace with zero (true) or null (false)");

    @Override
    public String toString() {
        return "SanitizeDecimalFields{}";
    }
}
package com.example.converter;

import io.confluent.connect.avro.AvroConverter;
import org.apache.kafka.connect.data.SchemaAndValue;
import org.apache.kafka.connect.errors.DataException;

public class PatchedAvroConverter extends AvroConverter {

    @Override
    public SchemaAndValue toConnectData(String topic, byte[] value) {
        try {
            return super.toConnectData(topic, value);
        } catch (DataException e) {
            if (e.getCause() instanceof NumberFormatException &&
                e.getCause().getMessage().contains("Zero length BigInteger")) {
                throw new DataException("PatchedAvroConverter: patched decimal default handling failed", e);
            }
            throw e;
        }
    }
}